Rails.application.routes.draw do

 get  '/get_driver' => "drivers#get_near_driver"
 get '/passengers/:passenger_id/requests/:request_id/drivers' => "drivers#get_near_driver"
 get '/passengers/:passenger_id/requests/:request_id/drivers/:driver_id/car' => "cars#get_car"
 get '/get_all_drivers' => "drivers#index"
 get '/get_all_cars' => "cars#index"
 put '/passengers/:passenger_id' => "passengers#terminate_ride"
  resources :passengers do
         resources :requests
       end   
  resources :drivers do
         resources:cars
  end
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
end
