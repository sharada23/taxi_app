class Driver < ApplicationRecord

has_one :request
has_one :passenger

has_one :car


#before_save :add_car
def get_driver_attributes params
    driver = params["driver"]
    data = {}
    data["name"] = driver["driver_name"]
    #data["car_id"] = driver["car_id"]
    #data["driver_id"] = Time.now.nsec.to_s
    data["latitude"] = driver["latitude"]
    data["longitude"] = driver["longitude"]

    data
end



def create params
   # status, data = validate_params get_mandatory_params, params["drivers"]
    #unless status
     #   return [true, data]
    #end
    driver = Driver.new
    driver["driver_name"] = params[:driver]["driver_name"]
    driver["latitude"] = params[:driver]["latitude"]
    driver["longitude"] = params[:driver]["longitude"]
    driver["is_free"] = true
    driver.save
    newcar = Car.new
    newcar.driver_id = driver.id
    newcar.car_name = "car" + '_' + driver.driver_name
    newcar.save
    driver.car_id = newcar.id
    driver.car_name = newcar.car_name
    driver.save 

    logger.debug "-------#{driver.errors.messages}"
    resp = {}
    resp["message"] = "Driver created successfully"
    return [true, resp]
end
end
