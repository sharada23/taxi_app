class Car < ApplicationRecord

has_many :requests
has_many :passengers, through: :requests
     
#belongs_to :driver
has_one :driver
end
