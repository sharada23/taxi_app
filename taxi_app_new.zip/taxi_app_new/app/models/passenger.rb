class Passenger < ApplicationRecord
include PassengerHelper
#include CommonCode


#attr_accessor :username, :password, :firstname, :request_id 
has_many :requests
has_many :drivers, through: :requests

#before_save :save_passenger
validates_uniqueness_of :user_name
#validates_uniqueness_of :passenger_id

=begin
def save_passenger
    password = self.password
    self.password_salt = BCrypt::Engine.generate_salt
    self.encrypted_password = BCrypt::Engine.hash_secret(password, password_salt)
end
=end

def get_passenger_attributes params
    passenger = params["passenger"]
    data = {}
    data["user_name"] = passenger["user_name"]
    #data["passenger_id"] = Time.now.nsec.to_s
    data["firstname"] = passenger["firstname"]
    data["password"] = passenger["password"]

    data
end



def create params
   # status, data = validate_params get_mandatory_params, params["passengers"]
    #unless status
     #   return [true, data]
    #end
    passenger = Passenger.new
    passenger["user_name"]  = params["passenger"]["user_name"]
    passenger["password"] = params["passenger"]["password"]
    passenger["firstname"] = params["passenger"]["firstname"]
    passenger.save 
    logger.debug "---passenger--#{passenger.inspect}"
=begin
    passenger_attributes = get_passenger_attributes params
    logger.debug "----#{passenger_attributes.inspect}"
    unless Passenger.create(passenger_attributes).valid?
        return [false, {"errors"=> {"message"=> "failed to create Passenger"}}]
    end
=end
    if !passenger.save
        logger.debug "---errro---#{passenger.errors.messages}"
        return [false, {"errors"=> {"message"=> "failed to create Passenger"}}]
    end
    resp = {}
    resp["message"] = "Passenger created successfully"

    return [true, resp]

end
   def terminate
       id = params[:pasenger_id]
       pass = params["passenger"]
       drive_id = pass[:request_id]
       drive = Driver.find(drive_id)
       drive.request_id = nil
       drive.is_free = true
       drive.save
   end
end
