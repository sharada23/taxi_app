class Request < ApplicationRecord

belongs_to :passenger
#belongs_to :driver

def get_request_attributes params
    request = params["request"]
    data = {}
    data["passenger_id"] = params["passenger_id"]
    data["passenger_name"] = request["passenger_name"]
    data["req_des"] = params["req_des"]
    data["latitude"] = request["latitude"]
    data["longitude"] = request["longitude"]

    data
end



def create params
   # status, data = validate_params get_mandatory_params, params["requests"]
    #unless status
     #   return [true, data]
    #end
    request_attributes = get_request_attributes params
      logger.debug "---request--#{request_attributes}"
    unless Request.create(request_attributes).valid?
logger.debug "-------#{Request.create.errors.messages}"
        return [false, {"errors"=> {"message"=> "failed to create Request"}}]
    end

    resp = {}
    resp["message"] = "Request created successfully"

    return [true, resp]



end
end
