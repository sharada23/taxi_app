module PassengerHelper

    
def get_mandatory_params
    {"user_name"=>String, "firstname"=>String,"password"=>String}
end

end 
