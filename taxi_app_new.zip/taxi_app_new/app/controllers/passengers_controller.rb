class PassengersController < ApplicationController

def index
    render json: Passenger.all

end

def create
    logger.debug "---here---#{params}"
    passenger = Passenger.new
    logger.debug "---passenger--#{passenger.errors.messages}"     
    status, data = passenger.create params
    if status
        render json: data, status: :ok
    else
        render json: data, status: :unprocessable_entity
    end
end
def terminate_ride
       id = params[:pasenger_id]
       pass = params["passenger"]
       drive_id = pass[:driver_id]
       drive = Driver.find(drive_id)
       drive.request_id = nil
       drive.is_free = true
       drive.save
   end

end
