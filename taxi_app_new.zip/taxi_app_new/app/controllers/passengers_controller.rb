class PassengersController < ApplicationController

def index
    @passengers = Passenger.all
    render 'index.html.erb'
#    render json: Passenger.all

end

def show
   @passenger = Passenger.find(params[:id])
end

def edit
end

def new
    @passenger = Passenger.new
end


def update
    respond_to do |format|
      if @passenger.update(passenger_params)
        format.html { redirect_to @passenger, notice: 'Passenger was successfully updated.' }
        format.json { head :no_content }
      else
        format.html { render action: 'edit' }
        format.json { render json: @passenger.errors, status: :unprocessable_entity }
      end
    end

end

def create
    username = params["passenger"]["user_name"]
    user = Passenger.find_by_user_name(username)
    if !user.nil?
       render json: "Passenger with username already exist", status: :ok
       return
    else
    logger.debug "---here---#{params}"
    passenger = Passenger.new
    logger.debug "---passenger--#{passenger.errors.messages}"     
    status, data = passenger.create params
    if status
        render json: data, status: :ok
    else
        render json: data, status: :unprocessable_entity
    end
   end
end
def terminate_ride
       id = params[:pasenger_id]
       pass = params["passenger"]
       drive_id = pass[:driver_id]
       drive = Driver.find(drive_id)
       drive.request_id = nil
       drive.is_free = true
       drive.save
   end

end
