class RequestsController < ApplicationController


def index
    pass_id = params[:passenger_id]
    req = Request.where(:passenger_id => pass_id).first
    render json: req
end

def show
    req_id = params[:id]
    logger.debug "---id--#{req_id}"
    req = Request.find(req_id)
    render json:req
end

def create
     if !params.has_key? "passenger_id"
        render json: {:errors => "Passnger_id not present"}
        return
    elsif !(params["passenger_id"].class == String)
        render json: {:errors => "Passenger_id is not of type string"}
        return
    end
           logger.debug "--ts--#{params["passenger_id"]}"
     id = params["passenger_id"]
           logger.debug "--ts--#{params["passenger_id"]}"
      ts = Passenger.where(:id => id) 
           logger.debug "--ts--#{ts.count}"
    if ts.count == 0
        logger.debug "---here--"
        render json: {:errors => "Passenger with Passenger_id does not exist"}, status: :unprocessable_entity
        return
    end

    logger.debug "---here---#{params}"
    request = Request.new

    status, data = request.create params
    if status
        render json: data, status: :ok
    else
        render json: data, status: :unprocessable_entity
    end
end

end
