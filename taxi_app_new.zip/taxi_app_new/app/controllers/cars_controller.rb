class CarsController < ApplicationController

def index
    render json: Car.all
   
end

def get_car
    assigned_car = {}
    id = params[:driver_id]
    cars = Car.where(:driver_id => id)
    if cars.count == 0
       render json: {"car_details" => "No car available"}
       return
    end
    assigned_car = cars.first
    assigned_car.request_id = params["request_id"]
    assigned_car.passenger_id = params["passenger_id"]
    assigned_car.save
    render json: {"car_details" => assigned_car}
   
end

  def get_car_per_driver
      id = params[:driver_id]
      car = Car.find_by_driver_id(id)
      render json: car

  end
end
