class DriversController < ApplicationController

def index

   render json: Driver.all
end

def get_all_drivers
     render json: Driver.all

end
def get_near_driver
    dist = []
    logger.debug "---here--"
    id = params[:request_id] 
    req = Request.where(:id => id).first
    reqlat = req.latitude
    reqlon = req.longitude
    req_id = req.id
      if req.car_type == "pink" 
         car = Car.where(:car_tye => "pink")
         car.each do |t|
            pdrlat = t.driver.latitude
            pdrlon = t.driver.longitude
            pdrid = t.driver.id
            dist << get_distance(reqlat,reqlon,drlat,drlon,driver_id)
         end
      else
        driver = Driver.where(:is_free => true)
        logger.debug "--driver--#{driver.inspect}"
        driver.all.each do |dr|
        drlat = dr.latitude
        drlon = dr.longitude
        driver_id = dr.id
        logger.debug "----ddd--#{drlat}---#{drlon}"
        dist << get_distance(reqlat,reqlon,drlat,drlon,driver_id)
      end
    end
        logger.debug "---final--#{dist}"
        final_driver = get_nearest_driver dist
        status,data = update_request final_driver,req_id
     if status
         render json: {"driver_details" => data}
     end
end


def get_distance(reqlat,reqlon,drlat,drlon,driver_id)
    final = {}
    d_ew = (reqlat - drlat) * Math.cos(reqlat)
    d_ns = (reqlon - drlon)
    d_lu = Math.sqrt(d_ew.to_f * d_ew.to_f + d_ns.to_f * d_ns.to_f)
    d_mi = ((2*Math::PI*3961.3)/360)*d_lu
    logger.debug "----ddd--#{d_mi}"
    final["driver_id"] = driver_id
    final["dmi"] = d_mi
    return final
end
  
def get_nearest_driver dist
   status,final_driver = get_pink_cars dist
   if !status
   final = dist.min_by{|hash| hash['dmi']}
   final_driver = final["driver_id"]
   logger.debug "--finalllll--#{final_driver}"
   return final_driver
   else
   return final_driver
end

end

def update_request final_driver,req_id
    status = false
    data = {}
   logger.debug "----fial--driver --#{final_driver}---#{req_id}" 
   req = Request.find_by_id(req_id)
   req.driver_id = final_driver
   pass = req.passenger
   pass.driver_id = final_driver
   pass.request_id = req_id
   pass.save
   req.save
  if req.save
     status = true
     data["driver_id"] = final_driver
     data["request_info"] = req
     data["passenger_info"] = pass
  end
   driver = Driver.find_by_id(final_driver)
   driver.request_id = req_id
   driver.passenger_id = req.passenger_id
   driver.is_free = false
   driver.save   
   logger.debug "---req--#{req.inspect}" 
   logger.debug "---req--#{driver.inspect}" 
   return [status,data]
end

def create
    if !params.has_key? "driver"
        render json: {:errors => "Driver not present"}
        return
    end
    driver = Driver.new

    status, data = driver.create params
    if status
        render json: data, status: :ok
    else
        render json: data, status: :unprocessable_entity
    end

end
   def get_pink_cars dist
       status = false
       pink_car = dist.map{|hash| hash["driver_id"]}
       pink_car.each do |t|
       car = Car.where(:driver_id => t).first
        if !car.nil?
           if car.car_tye == "pink"
              status = true
             @pink_car = t
            end
         end
      end
        final_driver = @pink_car
        return [status,final_driver]
end
end
